import { NextRequest, NextResponse } from 'next/server'
import { cookies } from 'next/headers'

export async function POST(requisicao: NextRequest) {
  const dados = await requisicao.json()
  const { username, password } = dados

  const senhaAmbiente = process.env.AUTH_PASSWORD

  if (!senhaAmbiente) {
    return NextResponse.json(
      { success: false, message: 'Erro de configuração' },
      { status: 500 }
    )
  }

  if (!username || !password) {
    return NextResponse.json(
      { success: false, message: 'Preencha todos os campos' },
      { status: 400 }
    )
  }

  if (password !== senhaAmbiente) {
    return NextResponse.json(
      { success: false, message: 'Senha incorreta' },
      { status: 401 }
    )
  }

  const armazenamentoCookies = await cookies()
  armazenamentoCookies.set('auth', 'true', {
    httpOnly: true,
    secure: process.env.NODE_ENV === 'production',
    sameSite: 'lax',
    maxAge: 60 * 60 * 24 * 7
  })

  return NextResponse.json({ success: true })
}

