'use client'

import { useState } from 'react'
import { useRouter } from 'next/navigation'
import './auth.css'

export default function AuthPage() {
  const [usuario, setUsuario] = useState('')
  const [senha, setSenha] = useState('')
  const [erro, setErro] = useState('')
  const [carregando, setCarregando] = useState(false)
  const navegador = useRouter()

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault()
    setErro('')
    setCarregando(true)

    const resposta = await fetch('/api/login', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ username: usuario, password: senha }),
    })

    const resultado = await resposta.json()

    if (resultado.success) {
      navegador.push('/home')
    } else {
      setErro(resultado.message || 'Login falhou')
    }
    setCarregando(false)
  }

  return (
    <div className="auth-wrapper">
      <div className="auth-box">
        <h1>Acesso</h1>
        <form onSubmit={handleLogin}>
          <div className="input-wrapper">
            <label htmlFor="usuario">Nome de usuário</label>
            <input
              type="text"
              id="usuario"
              value={usuario}
              onChange={(e) => setUsuario(e.target.value)}
              required
            />
          </div>
          <div className="input-wrapper">
            <label htmlFor="senha">Senha</label>
            <input
              type="password"
              id="senha"
              value={senha}
              onChange={(e) => setSenha(e.target.value)}
              required
            />
          </div>
          {erro && <div className="err-box">{erro}</div>}
          <button type="submit" disabled={carregando} className="submit-btn">
            {carregando ? 'Carregando...' : 'Acessar'}
          </button>
        </form>
      </div>
    </div>
  )
}

