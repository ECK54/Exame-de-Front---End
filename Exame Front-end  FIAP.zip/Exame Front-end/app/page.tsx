import { redirect } from 'next/navigation'
import { cookies } from 'next/headers'

export default async function HomePage() {
  const armazenamentoCookies = await cookies()
  const autenticado = armazenamentoCookies.get('auth')?.value === 'true'

  if (!autenticado) {
    redirect('/auth')
  }

  redirect('/home')
}

