export type LoginData = {
  username: string
  password: string
}

export type AuthResult = {
  success: boolean
  message?: string
}

